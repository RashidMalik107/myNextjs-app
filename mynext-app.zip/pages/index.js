import Head from "next/head";
import Typography from "@material-ui/core/Typography";

export default function HomePage() {
  return (
    <>
      <Head>
        <title>Boxbee: home</title>
      </Head>
      <Typography variant="h1">Home page</Typography>
      
      <Typography variant="body1">
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Optio nostrum
        rerum pariatur nihil iure eligendi sequi dolore magnam enim repellat id,
        neque, ab, mollitia suscipit. Fugiat sed est cum id.
      </Typography>
    </>
  );
}
