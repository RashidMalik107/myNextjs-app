export const blocksData = [
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },

];

export const blocksCardData = [
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },
    {
        name: 'Cody Fisher',
        designation: 'Front end web dev',
        role: 'Admin',
        url: 'https://8degreethemes.com/demo/edict-html/images/t1.jpg'
    },

];

